package io.ionic.nameofyourapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
